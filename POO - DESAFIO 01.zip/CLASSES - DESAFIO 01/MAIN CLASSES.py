from CLASSES import *



pessoa1 = Pessoa("Maria", 70, 45)

pessoa1.comer("maçã")
pessoa1.parar_de_comer()
pessoa1.andar()
pessoa1.parar_de_andar()
pessoa1.falar("Olá, tudo bem?")
pessoa1.parar_de_falar()


